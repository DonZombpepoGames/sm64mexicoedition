// 0x0500470C
const struct Animation *const bully_seg5_anims_0500470C[] = {
    &bully_seg5_anim_05004598,
    &bully_seg5_anim_050043D8,
    &bully_seg5_anim_050042A4,
    &bully_seg5_anim_050046F4,
    NULL,
};
