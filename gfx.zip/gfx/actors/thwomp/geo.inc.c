// 0x0C000248
const GeoLayout thwomp_geo[] = {
   GEO_SHADOW(SHADOW_SQUARE_SCALABLE, 0xB4, 300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, thwomp_seg5_dl_0500B750),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
